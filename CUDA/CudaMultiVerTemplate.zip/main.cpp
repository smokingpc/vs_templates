﻿#include "Precompile.h"

void Usage()
{
    _tprintf(_T("USAGE: \n"));
    _tprintf(_T("e.g. \n"));
}

int _tmain(int argc, TCHAR* argv[])
{}
