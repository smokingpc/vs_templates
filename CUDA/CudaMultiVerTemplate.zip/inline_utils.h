#pragma once
FORCEINLINE BOOLEAN CU_SUCCESS(cudaError status)
{
    return (cudaSuccess == status);
}
