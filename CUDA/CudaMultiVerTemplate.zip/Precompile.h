#pragma once

#include "cuda_runtime.h"
#include "device_launch_parameters.h"
#include <tchar.h>
#include <windows.h>
#include <stdio.h>

#include "Constant.h"
#include "Enumeration.h"
#include "Structure.h"
#include "inline_utils.h"
